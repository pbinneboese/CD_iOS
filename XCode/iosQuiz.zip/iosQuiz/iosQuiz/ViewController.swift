//
//  ViewController.swift
//  iosQuiz
//
//  Created by Paul Binneboese on 3/8/17.
//  Copyright © 2017 Paul Binneboese. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var names:[String] = ["Aaron", "Bobby", "Carmela", "Delilah", "Edwin", "Fernando", "Gabriel", "Hugo"]
    @IBOutlet weak var theName: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        theName.text = "READY?"
    }

    @IBAction func callButton(_ sender: UIButton) {
        let i = Int(arc4random_uniform(UInt32(names.count)))
        theName.text = names[i]
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

